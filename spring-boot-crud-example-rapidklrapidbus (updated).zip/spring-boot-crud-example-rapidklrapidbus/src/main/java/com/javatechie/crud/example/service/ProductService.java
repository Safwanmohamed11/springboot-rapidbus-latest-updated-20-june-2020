package com.javatechie.crud.example.service;

import com.javatechie.crud.example.entity.Product;
import com.javatechie.crud.example.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository repository;

    public Product saveProduct (Product product) {
        return repository.save(product);
    }
    public List<Product> saveProducts (List<Product> products) {
        return repository.saveAll(products);
    }

    public List<Product> getProducts() {
        return repository.findAll();
    }
    public Product getProductsById(int id) {
        return repository.findById(id).orElse(null);
    }
        public Product getProductsByName(String name) {
            return repository.findByName(name);
    }

    public String deleteProduct(int id) {
        repository.deleteById(id);
        return "product removed !!"+id;
    }

    public Product updateProduct(Product product){
        Product existingProduct = repository.findById(product.getId()).orElse(null);
        existingProduct.setName (product.getName ());
        existingProduct.setBus_number(product.getBus_number());
        existingProduct.setBus_model(product.getBus_model());
        existingProduct.setMaintenance_order(product.getMaintenance_order());
        existingProduct.setTime_Start(product.getTime_Start());
        existingProduct.setTime_Completed(product.getTime_Completed());
        existingProduct.setItem_front_visual_check(product.getItem_front_visual_check());
        existingProduct.setItem_front_hardness_and_earthing_check(product.getItem_front_hardness_and_earthing_check());
        existingProduct.setSide_visual_check(product.getSide_visual_check());
        existingProduct.setSide_hardness_and_earthing_check(product.getSide_hardness_and_earthing_check());
        existingProduct.setRear_visual_check(product.getRear_visual_check());
        existingProduct.setRear_front_hardness_and_earthing_check(product.getRear_front_hardness_and_earthing_check());
        existingProduct.setController_content_check(product.getController_content_check());
        existingProduct.setController_visual_check(product.getController_visual_check());
        existingProduct.setTruck_radio_visual_check(product.getTruck_radio_visual_check());
        existingProduct.setTruck_radio_hardness_earthing_check(product.getTruck_radio_hardness_earthing_check());
        existingProduct.setTruck_radio_content_check(product.getTruck_radio_content_check());
        existingProduct.setTracker_visual_check(product.getTracker_visual_check());
        existingProduct.setTracker_hardness_earthing_check(product.getTracker_hardness_earthing_check());
        existingProduct.setTracker_panic_button(product.getTracker_panic_button());
        existingProduct.setTracker_CBTS_cable(product.getTracker_CBTS_cable());
        existingProduct.setAnnouncerment_player_visual_check(product.getAnnouncerment_player_visual_check());
        existingProduct.setAnnouncerment_player_hardness_earthing_check(product.getAnnouncerment_player_hardness_earthing_check());
        existingProduct.setAnnouncerment_player_content_check(product.getAnnouncerment_player_content_check());
        existingProduct.setAnnouncerment_player_speaker(product.getAnnouncerment_player_speaker());
        existingProduct.setAnnouncerment_player_microphone(product.getAnnouncerment_player_microphone());
        existingProduct.setInfortainment_sys_LCD_Monitor_Front(product.getInfortainment_sys_LCD_Monitor_Front());
        existingProduct.setInfortainment_sys_LCD_Monitor_Rear(product.getInfortainment_sys_LCD_Monitor_Rear());
        existingProduct.setInfortainment_sys_Visual_check(product.getInfortainment_sys_Visual_check());
        existingProduct.setInfortainment_sys_Hardness_and_earthing_check(product.getInfortainment_sys_Hardness_and_earthing_check());
        existingProduct.setCCTV_sys_item_LCD_Monitor(product.getCCTV_sys_item_LCD_Monitor());
        existingProduct.setCCTV_sys_item_Camera_Condition(product.getCCTV_sys_item_Camera_Condition());
        existingProduct.setCCTV_sys_item_Visual_Check(product.getCCTV_sys_item_Visual_Check());
        existingProduct.setCCTV_sys_item_Hardness_and_earthing_check(product.getCCTV_sys_item_Hardness_and_earthing_check());
        existingProduct.setCCTV_sys_item_DVR_NVR(product.getCCTV_sys_item_DVR_NVR());
        existingProduct.setFCS_CBTS_ETM_Visual_Check(product.getFCS_CBTS_ETM_Visual_Check());
        existingProduct.setFCS_CBTS_ETM_Hardness_and_Earthing_Check(product.getFCS_CBTS_ETM_Hardness_and_Earthing_Check());
        existingProduct.setFCS_CBTS_Reader_Visual_Check(product.getFCS_CBTS_Reader_Visual_Check());
        existingProduct.setFCS_CBTS_Reader_Hardness_and_Earthing_Check(product.getFCS_CBTS_Reader_Hardness_and_Earthing_Check());
        existingProduct.setFCS_BTS_Reader_Visual_Check(product.getFCS_BTS_Reader_Visual_Check());
        existingProduct.setFCS_BTS_Reader_Hardness_and_Earthing_Check(product.getFCS_BTS_Reader_Hardness_and_Earthing_Check());
        existingProduct.setFCS_Cash_Vault_lock_condition(product.getFCS_Cash_Vault_lock_condition());
        existingProduct.setFCS_Cash_Vault_visual_check(product.getFCS_Cash_Vault_visual_check());
        return repository.save(existingProduct);
    }







}
