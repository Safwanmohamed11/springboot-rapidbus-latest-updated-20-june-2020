package com.javatechie.crud.example.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RAPIDBUS_TBL")
public class Product {

    @Id
    @GeneratedValue
    private int id;
    private char name;
    private int bus_number;
    private char bus_model;
    private char maintenance_order;
    private float time_Start;
    private float time_Completed;
    private char item_front_visual_check;
    private char item_front_hardness_and_earthing_check;
    private char side_visual_check;
    private char side_hardness_and_earthing_check;
    private char rear_visual_check;
    private char rear_front_hardness_and_earthing_check;
    private char controller_content_check;
    private char controller_visual_check;
    private char truck_radio_visual_check;
    private char truck_radio_hardness_earthing_check;
    private char truck_radio_content_check;
    private char tracker_visual_check;
    private char tracker_hardness_earthing_check;
    private char tracker_panic_button;
    private char tracker_CBTS_cable;
    private char announcerment_player_visual_check;
    private char announcerment_player_hardness_earthing_check;
    private char announcerment_player_content_check;
    private char announcerment_player_speaker;
    private char announcerment_player_microphone;
    private char infortainment_sys_LCD_Monitor_Front;
    private char infortainment_sys_LCD_Monitor_Rear;
    private char infortainment_sys_Visual_check;
    private char infortainment_sys_Hardness_and_earthing_check;
    private char CCTV_sys_item_LCD_Monitor;
    private char CCTV_sys_item_Camera_Condition;
    private char CCTV_sys_item_Visual_Check;
    private char CCTV_sys_item_Hardness_and_earthing_check;
    private char CCTV_sys_item_DVR_NVR;
    private char FCS_CBTS_ETM_Visual_Check;
    private char FCS_CBTS_ETM_Hardness_and_Earthing_Check;
    private char FCS_CBTS_Reader_Visual_Check;
    private char FCS_CBTS_Reader_Hardness_and_Earthing_Check;
    private char FCS_BTS_Reader_Visual_Check;
    private char FCS_BTS_Reader_Hardness_and_Earthing_Check;
    private char FCS_Cash_Vault_lock_condition;
    private char FCS_Cash_Vault_visual_check;

    public Integer getId() {

        return null;
    }

    public Object getName() {

        return null;
    }

    public void setName(Object name) {
        
    }

    public Object getBus_number() {

        return null;
    }

    public void setBus_number(Object bus_number) {
        
    }

    public Object getBus_model() {

        return null;
    }

    public void setBus_model(Object bus_model) {
    }

    public Object getMaintenance_order() {

        return null;
    }

    public void setMaintenance_order(Object maintenance_order) {
    }

    public Object getTime_Start() {

        return null;
    }

    public void setTime_Start(Object time_start) {
    }

    public Object getTime_Completed() {

        return null;
    }

    public void setTime_Completed(Object time_completed) {
    }

    public Object getItem_front_visual_check() {

        return null;
    }

    public void setItem_front_visual_check(Object item_front_visual_check) {
    }

    public Object getItem_front_hardness_and_earthing_check() {

        return null;
    }

    public void setItem_front_hardness_and_earthing_check(Object item_front_hardness_and_earthing_check) {
    }

    public Object getSide_visual_check() {

        return null;
    }

    public void setSide_visual_check(Object side_visual_check) {
    }

    public Object getSide_hardness_and_earthing_check() {

        return null;
    }

    public void setSide_hardness_and_earthing_check(Object side_hardness_and_earthing_check) {
    }

    public Object getRear_visual_check() {

        return null;
    }

    public void setRear_visual_check(Object rear_visual_check) {
    }

    public Object getRear_front_hardness_and_earthing_check() {

        return null;
    }

    public void setRear_front_hardness_and_earthing_check(Object rear_front_hardness_and_earthing_check) {
    }

    public Object getController_content_check() {

        return null;
    }

    public void setController_content_check(Object controller_content_check) {
    }

    public Object getController_visual_check() {

        return null;
    }

    public void setController_visual_check(Object controller_visual_check) {
    }

    public Object getTruck_radio_visual_check() {

        return null;
    }

    public void setTruck_radio_visual_check(Object truck_radio_visual_check) {
    }

    public Object getTruck_radio_hardness_earthing_check() {

        return null;
    }

    public void setTruck_radio_hardness_earthing_check(Object truck_radio_hardness_earthing_check) {
    }

    public Object getTruck_radio_content_check() {

        return null;
    }

    public void setTruck_radio_content_check(Object truck_radio_content_check) {
    }

    public Object getTracker_visual_check() {

        return null;
    }

    public void setTracker_visual_check(Object tracker_visual_check) {
    }

    public Object getTracker_hardness_earthing_check() {

        return null;
    }

    public void setTracker_hardness_earthing_check(Object tracker_hardness_earthing_check) {
    }

    public Object getTracker_panic_button() {

        return null;
    }

    public void setTracker_panic_button(Object tracker_panic_button) {
    }

    public Object getTracker_CBTS_cable() {

        return null;
    }

    public void setTracker_CBTS_cable(Object tracker_cbts_cable) {
    }

    public Object getAnnouncerment_player_visual_check() {

        return null;
    }

    public void setAnnouncerment_player_visual_check(Object announcerment_player_visual_check) {
    }

    public Object getAnnouncerment_player_hardness_earthing_check() {

        return null;
    }

    public void setAnnouncerment_player_hardness_earthing_check(Object announcerment_player_hardness_earthing_check) {
    }

    public Object getAnnouncerment_player_content_check() {

        return null;
    }

    public void setAnnouncerment_player_content_check(Object announcerment_player_content_check) {
    }

    public Object getAnnouncerment_player_speaker() {

        return null;
    }

    public void setAnnouncerment_player_speaker(Object announcerment_player_speaker) {
    }

    public Object getAnnouncerment_player_microphone() {

        return null;
    }


    public void setAnnouncerment_player_microphone(Object announcerment_player_microphone) {
    }

    public Object getInfortainment_sys_LCD_Monitor_Front() {

        return null;
    }

    public void setInfortainment_sys_LCD_Monitor_Front(Object infortainment_sys_lcd_monitor_front) {
    }

    public Object getInfortainment_sys_LCD_Monitor_Rear() {

        return null;
    }

    public void setInfortainment_sys_LCD_Monitor_Rear(Object infortainment_sys_lcd_monitor_rear) {
    }

    public Object getInfortainment_sys_Visual_check() {

        return null;
    }

    public void setInfortainment_sys_Visual_check(Object infortainment_sys_visual_check) {
    }

    public Object getInfortainment_sys_Hardness_and_earthing_check() {

        return null;
    }

    public void setInfortainment_sys_Hardness_and_earthing_check(Object infortainment_sys_hardness_and_earthing_check) {
    }

    public Object getCCTV_sys_item_LCD_Monitor() {

        return null;
    }

    public void setCCTV_sys_item_LCD_Monitor(Object cctv_sys_item_lcd_monitor) {
    }

    public Object getCCTV_sys_item_Camera_Condition() {

        return null;
    }

    public void setCCTV_sys_item_Camera_Condition(Object cctv_sys_item_camera_condition) {
    }

    public Object getCCTV_sys_item_Visual_Check() {

        return null;
    }

    public void setCCTV_sys_item_Visual_Check(Object cctv_sys_item_visual_check) {
    }

    public Object getCCTV_sys_item_Hardness_and_earthing_check() {

        return null;
    }

    public void setCCTV_sys_item_Hardness_and_earthing_check(Object cctv_sys_item_hardness_and_earthing_check) {
    }

    public Object getCCTV_sys_item_DVR_NVR() {

        return null;
    }

    public void setCCTV_sys_item_DVR_NVR(Object cctv_sys_item_dvr_nvr) {
    }

    public Object getFCS_CBTS_ETM_Visual_Check() {

        return null;
    }

    public void setFCS_CBTS_ETM_Visual_Check(Object fcs_cbts_etm_visual_check) {
    }

    public Object getFCS_CBTS_ETM_Hardness_and_Earthing_Check() {

        return null;
    }

    public void setFCS_CBTS_ETM_Hardness_and_Earthing_Check(Object fcs_cbts_etm_hardness_and_earthing_check) {
    }

    public Object getFCS_CBTS_Reader_Visual_Check() {

        return null;
    }

    public void setFCS_CBTS_Reader_Visual_Check(Object fcs_cbts_reader_visual_check) {
    }

    public Object getFCS_CBTS_Reader_Hardness_and_Earthing_Check() {

        return null;
    }

    public void setFCS_CBTS_Reader_Hardness_and_Earthing_Check(Object fcs_cbts_reader_hardness_and_earthing_check) {
    }

    public Object getFCS_BTS_Reader_Visual_Check() {

        return null;
    }

    public void setFCS_BTS_Reader_Visual_Check(Object fcs_bts_reader_visual_check) {
    }


    public Object getFCS_BTS_Reader_Hardness_and_Earthing_Check() {

        return null;
    }

    public void setFCS_BTS_Reader_Hardness_and_Earthing_Check(Object fcs_bts_reader_hardness_and_earthing_check) {
    }

    public Object getFCS_Cash_Vault_lock_condition() {

        return null;
    }

    public void setFCS_Cash_Vault_lock_condition(Object fcs_cash_vault_lock_condition) {
    }

    public Object getFCS_Cash_Vault_visual_check() {

        return null;
    }

    public void setFCS_Cash_Vault_visual_check(Object fcs_cash_vault_visual_check) {
    }
}
